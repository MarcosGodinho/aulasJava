package aula1;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;

public class exercicio3 {
    public static void main(String[] args) {
        JedisPool pool = new JedisPool("127.0.0.1", 6379);
        Jedis jedis = pool.getResource();

        //create(jedis);
        incrementa(jedis, "programa:execuções");
    }

    private static void incrementa(Jedis jedis, String key) {
        jedis.incr(key);
    }
    private static void create(Jedis jedis) {
        jedis.set("programa:execuções", "1");
    }
}
