package aula1;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;
import java.util.Random;

public class exercicio2 {
    private static final Logger log = LoggerFactory.getLogger(exercicio2.class);

    public static void main(String[] args) {
        JedisPool pool = new JedisPool("127.0.0.1", 6379);
        Jedis jedis = pool.getResource();

    Random gerador = new Random();

    for(int i = 0; i < 10; i++) {
        int key = gerador.nextInt();
        int values = gerador.nextInt();
        jedis.set(String.valueOf(key), String.valueOf(values));
        }
    }
}
