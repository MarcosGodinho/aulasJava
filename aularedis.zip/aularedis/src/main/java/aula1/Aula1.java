package aula1;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;

public final class Aula1 {
    private static final Logger log = LoggerFactory.getLogger(Aula1.class);

    private Aula1() {}

    public static void main(String[] args) {
        JedisPool pool = new JedisPool("127.0.0.1", 6379);
        Jedis jedis = pool.getResource();
        log.info(jedis.ping());
        log.info(jedis.echo("Hello World"));
        jedis.close();
        pool.close();
        log.info("Ok");
    }
}
