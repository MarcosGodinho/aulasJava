package aula1;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;
import java.util.ArrayList;

public class exercicio4 {

    public static void main(String[] args) {
        JedisPool pool = new JedisPool("127.0.0.1", 6379);
        Jedis jedis = pool.getResource();
        jedis.aclList();

        ArrayList array = new ArrayList<String>(){
            {
                add("Marcos");
                add("Eduardo");
                add("Matheus");
                add("Sara");
                add("Marcao");
                add("Marquinho");
                add("Mark");
                add("Markin");
                add("Março");
                add("Marcinho");
            }
        };

        // Exercicio 4
        for(int i = 0; i < array.size(); i++) {
            String key = "escola;alunos";
            jedis.lpush(key, String.valueOf(array.get(i)));
            System.out.println(key + " " + array.get(i));
        }

        // Exercicio 5
        for(int i = 0; i < array.size(); i++) {
            int key = i;
            jedis.lpush(String.valueOf(key), String.valueOf(array.get(i)));
            System.out.println(key + " " + array.get(i));
        }
    }
}
